﻿using StationaryServer2.Models.Stationary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StationaryServer2.Repository
{
    public interface IRepositoryAll
    {
    
    }
}
