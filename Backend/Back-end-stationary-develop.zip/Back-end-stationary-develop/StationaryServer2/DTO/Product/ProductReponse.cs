﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StationaryServer2.DTO.Product
{
    public class ProductReponse : ProductRequest
    {
        public string ImageUrl { get; set; }
    }
}
